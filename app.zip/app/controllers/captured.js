function showDetails(e){
	var name = e.rowData.title;
	var ctrl = Alloy.createController('capturedDetails',{capturedName:name});
	$.capturedTab.open(ctrl.getView());
	
}