var name = arguments[0].capturedName;

$.capturedDetailsWindow.title = name;
