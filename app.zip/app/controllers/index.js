function doClick(e) {  
    alert($.label.text);
}

$.index.open();
