function showDetails(e){
	var name = e.rowData.title;
	var ctrl = Alloy.createController('fugitivesDetails',{fugitiveName:name});
	$.fugitivesTab.open(ctrl.getView());
	
}
