var name = arguments[0].fugitiveName;

$.fugitiveDetailsWindow.title = name;
